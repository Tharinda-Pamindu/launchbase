#!/bin/env python

from app.cli import cli

if __name__ == "__main__":
    cli()
